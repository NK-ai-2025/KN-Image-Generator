# KN Image Generator

This is a React + Vite project for generating images using AI.
Built with React, Tailwind CSS, Framer Motion, and Google Generative AI.
